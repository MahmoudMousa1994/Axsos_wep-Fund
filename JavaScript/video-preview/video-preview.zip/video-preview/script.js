console.log("page loaded...");
function playvideo(element){
    element.play();
}
function pausevideo(element){
    element.pause();
    element.currentTime = 0;
}