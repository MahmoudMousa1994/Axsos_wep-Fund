// decreasinng multiples of 3
var arr=[];
for(var i=100;i>=0;i--){
    if(i%3==0){
       arr.push(i);
    }
}
 console.log(arr);