// print the given sequence
for(var i=4;i>=-3.5;i-=1.5){
    console.log(i);
}