// sum of numbers from 1 to 10
var sum=0
for(var i=0;i<=10;i++){
    sum+=i;
}
console.log(sum);