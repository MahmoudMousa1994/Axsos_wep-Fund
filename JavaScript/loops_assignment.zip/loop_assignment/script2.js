// reverse counting
var arr=[];
for(var i=10;i>=0;i--){
    arr.push(i);
}
console.log(arr);