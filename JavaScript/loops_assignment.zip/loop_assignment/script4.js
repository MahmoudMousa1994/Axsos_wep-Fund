// odd numbers from 1 to 20
var arr=[];
for (var i =1 ; i<=20;i++){
    if(i%2===1){
        arr.push(i);    
    }    
}
console.log(arr);