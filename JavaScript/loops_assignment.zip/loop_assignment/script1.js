// print numbers form 1 to 10
var arr=[];
for(var i=1;i<=10;i++){
    arr.push(i);
}
console.log(arr);